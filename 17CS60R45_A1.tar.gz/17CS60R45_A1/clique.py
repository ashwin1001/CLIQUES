#Program for finding cliques in a graph

import sys

adjacency_list = {}                             #for storing adjacency list
adjacency_list2={}                              #for storing visited nodes along with their adjacency list
size_of_clique = 0                              #for taking the size of clique (K)
set_of_marked_nodes=set()                       #for storing visited nodes only
set_of_cliques=set()                            #for storing cliques

def fetch_data():                               #Function to fetch adjacency list from file and store in dictionary
    file_name=sys.argv[1]
    file_object=open(file_name)               #creating file object by taking file name from argument variables
    global size_of_clique
    size_of_clique=file_object.readline()       #fetching the value of K

    for line in file_object:                    #storing adjacency list in dictionary(adjacency_list)
        list=line.split()
        node=list.pop(0)
        adjacency_list[node]=set(list)
    file_object.close()


def print_adjacency_list():                     #function to print adjacency list
    for key,value in adjacency_list.iteritems():
        print key+"  -->  ",
        for element in value:
            print element+', ',

def print_set(set):                             #function to print a set
    for k in set:
        for l in k:
            print l+" ",
        print '\n'
#Recurive function to find all the cliques
def get_clique(depth,root,current_node,traversed_nodes_set,current_intersecting_set):
    depth=depth-1                                           #setting the level of recursion
    if depth!=0 and len(current_intersecting_set)==0:       #base cases
        return
    if depth==0 and len(current_intersecting_set)==0:
        return
    if depth==0 and len(current_intersecting_set)!=0:       #termination case when all the nodes in the clique are traversed
        global set_of_cliques
        for node1 in current_intersecting_set:
            new_set=set()
            new_set.add(node1)
            set1=traversed_nodes_set.union(new_set)
            set_of_cliques.add(frozenset(set1))
        return
    else:
        for neighbour in current_intersecting_set:      #recursively calling for each neighbour
            if neighbour in adjacency_list2:            #checking if neighbour is already traversed
                continue                                #optimizing function by reducing calls
            intersect=set()
            intersect=adjacency_list[neighbour].difference(traversed_nodes_set) #removing visited nodes from neighbours list
            intersect=current_intersecting_set.intersection(intersect)          #finding nodes that links to all the traversed nodes till now
            trav_set=traversed_nodes_set
            set2=set()
            set2.add(neighbour)
            trav_set=traversed_nodes_set.union(set2)                            #putting neighbour to traversed list
            get_clique(depth,root,neighbour,trav_set,intersect)                 #calling recursive function for neighbour



def find_clique():                                          #abstract function that calls get_clique function
    fetch_data()
    if int(size_of_clique)==0:                              #corner case for, if the vaue of k is 0
        print 'no cliques of 0 nodes...pls give a number greater than 0'
        exit()

    elif int(size_of_clique)==1 :                           #corner case: if the value of k=1
        for key in adjacency_list:
            set1=set()
            set1.add(key)
            set2=frozenset(set1)
            set_of_cliques.add(set2)

    else:
        for key,value in adjacency_list.iteritems():                #traversing each node in the adjacency list one by one
            depth_counter=int(size_of_clique)-1                     #defining the depth of recursion for finding the clique
            global set_of_marked_nodes                              #set the visiting node as marked
            set_of_marked_nodes.add(key)

            #store the adjacency list to find the clique by intersection of neighbours
            adjacency_list2[key]=value
            traversed_nodes=set()
            traversed_nodes.add(key)
            get_clique(depth_counter,key,key,traversed_nodes,value)



def generate_DotFile():                         #function to generate the dot file for the given input file
    clique=set_of_cliques.pop()
    file=open('output.dot','r+')
    file.write('Graph{ \n')
    trav=set()
    for key,value in adjacency_list.iteritems():
        file.write(key+' '),
    file.write('\n')
    for k,val in adjacency_list.iteritems():
        trav.add(k)
        for node in val:
            if node in trav:
                continue
            file.write(k+" -- "+node+"\n")
    for clique_node in clique:
        file.write(clique_node+' [fillcolor=green,style=filled]\n')
    file.write('\n}')

#function for graph generation from the generate dot file
def generate_graph():
    generate_DotFile()
    from subprocess import check_call
    check_call(['dot','-Tpng','output.dot','-o','graph_image.png'])

if __name__ == "__main__":
    find_clique()
    if len(set_of_cliques)==0:              #case if no cliques found
        print 'no cliques of length ',
        print size_of_clique,
        exit()
    else:
        print 'cliques of size '+size_of_clique
        print_set(set_of_cliques)
        generate_graph()